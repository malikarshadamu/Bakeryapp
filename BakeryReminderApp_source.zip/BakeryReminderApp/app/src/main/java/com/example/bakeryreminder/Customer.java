package com.example.bakeryreminder;
import org.json.*;
public class Customer {
 public String id,name,phone,birthday,anniversary,fav,note;
 public Customer(String id,String name,String phone,String birthday,String anniversary,String fav,String note){this.id=id;this.name=name;this.phone=phone;this.birthday=birthday;this.anniversary=anniversary;this.fav=fav;this.note=note;}
 public JSONObject toJson() throws JSONException { JSONObject o=new JSONObject(); o.put("id",id);o.put("name",name);o.put("phone",phone);o.put("birthday",birthday);o.put("anniversary",anniversary);o.put("fav",fav);o.put("note",note); return o; }
 public static Customer fromJson(JSONObject o){ return new Customer(o.optString("id"),o.optString("name"),o.optString("phone"),o.optString("birthday"),o.optString("anniversary"),o.optString("fav"),o.optString("note")); }
}
